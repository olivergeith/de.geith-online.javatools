########################################################################################################
What are we doing here ?
########################################################################################################
This is the folder where you can put your own sets of weather icons.
Create subfolder(s) in here for example "MyWeatherIcons" and place your png's in that folder.

The directory structure should look like this:

./custom/weather/
           -->   (AOKP) RR original
           -->   (AOKP) RR Weather Trick
           -->   MyWeatherIcons
           -->   ...
           
After that restart the "Battery Icon Creator". 
Hopefully it has found your new Folder "MyWeatherIcons" and will present it in the weather dropdownbox.



########################################################################################################
Attention !!!
########################################################################################################
The 2 predefined Iconsets here "(AOKP)..." are for AOKP-Roms only! Stock Roms may have different filenames. 
Don't flash these to Stock Roms unless you made sure the icon names fit!!!!!
########################################################################################################
 